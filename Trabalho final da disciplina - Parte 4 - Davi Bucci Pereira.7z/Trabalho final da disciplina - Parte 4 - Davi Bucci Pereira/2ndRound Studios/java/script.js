function validacao(){
		
			var formulario = document.forms["form2nd"]
			
				var x = document.forms["form2nd"]["nome"].value;
					if(x == null || x == ""){
						alert("Informe o nome.");
						return false;
					}
				
				var x = document.forms["form2nd"]["email"].value;
					if (x == null || x == ""){
						alert("Informe o e-mail.");
						return false;
				}else{
					var x = document.forms["form2nd"]["email"].value;
					var atpos = x.indexOf("@");
					var dotpos = x.lastIndexOf(".");}
					
						if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length){
							alert("E-mail inválido. Informe um e-mail válido! Ex: fulano@outlook.com");
							return false;
					}
					
				var x = document.forms["form2nd"]["telefone"].value;
					if (x == null || x == ""){
						alert("Informe o telefone.");
						return false;
				}else{
					var x = document.forms["form2nd"]["telefone"].value;
						if (isNaN(x) || x < 0){
							alert("Informe apenas números! Ex: 999999999");
							return false;
					}
					
				}
					
				var x = document.forms["form2nd"]["nascimento"].value;
					if (x == null || x == ""){
						alert("Informe a data de nascimento.");
						return false;
				}else{
					var date = x;
					var ardt = new Array;
					var ExpReg = new RegExp ("(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/[12][0-9]{3}");
					ardt = date.split ("/");
					erro = false;
        
						if (date.search(ExpReg) == -1){
							erro = true;
						}else if (((ardt[1]==4) || (ardt[1]==6) || (ardt[1]==9) || (ardt[1]==11)) && (ardt[0]>30))
							erro = true;

						else if (ardt[1] == 2){
							if ((ardt[0] > 28) && ((ardt[2] % 4) != 0))
								erro = true;
							if ((ardt[0] > 29) && ((ardt [2] % 4) == 0))
								erro = true;
						}if (erro){
							alert("Data inválida. Informe uma data válida! Ex: 01/01/2020");
							return false;
					}
					
				}
					
				var x = document.forms["form2nd"]["mensagem"].value;
					if (x == null || x == ""){
						alert("Digite a sua mensagem.");
						return false;
				}	
			
			}		